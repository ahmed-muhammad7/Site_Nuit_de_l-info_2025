# Storyline
1. Le Concept : "L'École de Demain" (Le Fil Conducteur)
Pour que ce soit motivant, il faut que le joueur ait un but. 
    - Le Scénario : L'établissement est "malade" (trop de dépenses, PC lents, dépendance aux GAFAM).
    - Le Personnage (Mascotte) : Appelez-le "Nirdy". C'est un technicien un peu "geek mais pédagogue" qui guide l'utilisateur.
    - L'Objectif : Faire passer l'établissement du statut "Obsolète & Dépendant" au statut "NIRD".
    - La Récompense : À chaque bonne réponse, affichez une animation un peu cool (genre des confettis et un petit son), 
    


- 	Question Windows 11 !
    - Mascotte : "Aïe ! Ces 20 ordinateurs fonctionnent bien, mais Windows 11 dit qu'ils sont trop vieux (pas de puce TPM). On fait quoi ?"
        - Choix A : On jette tout et on rachète du neuf. (en raison on mets Coûteux, Polluant, on ne le mets pas dans la question (sa donne la réponse))
         - Choix B : On installe un système d'exploitation léger Basé sur linux. (la on donne des exemples de distro (genre linux mint ou zorin os lite (avec des logos c’est mieux))
        - Info Bulle : Expliquer que le matériel est encore bon, c'est le logiciel qui est artificiellement limitant. C’est des explications que l’on donnera dans les deux cas
- Question Vitesse (SSD vs HDD) :
    - Mascotte : "Les profs se plaignent que les PC mettent 10 minutes à démarrer. C'est foutu ?"
        - Choix A : On remplace les disques durs mécaniques (HDD) par des SSD.
        - Choix B : On reste sur des vieux disques mechaniques qui ralentissent notre travaille
        - Info Bulle : Un SSD coûte 20€ et redonne approximativement 5 ans de vie à un PC.
Niveau 2 : Le Système (L'Indépendance)
Ici, on introduit les distributions Linux selon l'usage.
-	Question Usage "Bureautique Simple" (CDI, Admin) :
    - Mascotte : "Pour le CDI, on a juste besoin de naviguer sur le web et écrire des textes. On met quoi sur les vieux PC ?"
        - Choix A : On reste sur Windows 7 ou Windows 10, avec la suite office, parce que ce sont des licences que l’on payes et qui sont plus ou moins rentable par rapport a notre matériel informatique
        - Choix B : on passe a linux et on utilise des suites open-source comme libreoffice 
        - Infobulle : On parle de zorin os et/ou linux mint
        - Pourquoi : Interface très proche de Windows 7/10, ne dépayse pas les utilisateurs (bouton démarrer en bas à gauche).
-	Question "Vieux PC" (Obsolescence) :
    - Mascotte : "On a retrouvé des PC d'il y a 12 ans dans la cave. Poubelle ?"
        - Choix A: Il est trop vieux, il ne peut plus fonctionner correctement.
        - Choix B : Un PC vieux de 12 ans peut encore être utilisé avec un système léger comme Linux Lite ou Antix.
         - Pourquoi : En effet, même un PC vieux de 12 ans peut être réutilisé avec des systèmes d'exploitation légers, comme Linux Lite ou Antix, qui consomment très peu de ressources (RAM et CPU), permettant au matériel ancien de fonctionner de manière plus fluide. 

Question : L’Europe doit-elle privilégier les solutions technologiques locales plutôt que les services américains pour garantir sa souveraineté numérique ?
•	Choix A : Oui, investir dans des solutions européennes permettrait de réduire la dépendance aux géants américains et de renforcer la souveraineté numérique de l’Europe.
•	Choix B : Non, il est préférable de continuer à utiliser des services américains qui sont considérés comme des biens communs et qui offrent des avantages économiques indéniables.

Pourquoi : Il est important de soutenir les entreprises européennes pour protéger la souveraineté numérique de l'Europe, notamment face aux enjeux géopolitiques et aux intérêts capitalistiques des grandes entreprises technologiques américaines.
